# fMess Android companion

Vietnamese setup and limitations: see [README_VI.md](README_VI.md).

This folder is an Android WebView companion for Messenger, not a direct mobile compilation of the desktop Tauri application. It deliberately does not collect credentials; sign-in takes place on Facebook's HTTPS page.
