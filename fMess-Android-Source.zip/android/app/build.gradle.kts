plugins {
    id("com.android.application")
}

android {
    namespace = "io.github.toanbku.fmess.android"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.github.toanbku.fmess.android"
        minSdk = 24
        targetSdk = 35
        versionCode = 1028
        versionName = "0.1.28-android.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        release {
            // Debug APK is built by the included workflow. Configure a
            // private signing key before distributing a release APK.
            isMinifyEnabled = false
        }
    }
}
