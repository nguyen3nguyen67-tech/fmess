# fMess Android – bản thử nghiệm 0.1.28

Đây là **ứng dụng Android WebView độc lập**, dùng giao diện Messenger tại trang HTTPS chính thức `facebook.com/messages/`. Đây không phải bản biên dịch trực tiếp của ứng dụng desktop Tauri.

## Tính năng hiện có

- Mở Messenger trong ứng dụng và dùng cookie WebView để giữ phiên đăng nhập trên thiết bị.
- JavaScript và DOM Storage cần thiết cho Messenger.
- Hỗ trợ tải tệp xuống, chọn tệp đính kèm, xin quyền camera/micro khi trang yêu cầu.
- Nút quay lại, tải lại, mở Messenger trong trình duyệt và chia sẻ liên kết.
- Chặn nội dung HTTP không mã hóa; không đọc hay lưu mật khẩu.

## Những phần desktop chưa được chuyển

Các chức năng phụ thuộc cửa sổ desktop như khay hệ thống, badge ở Dock/taskbar, phím tắt toàn hệ thống, cửa sổ cài đặt Tauri và thông báo native theo logic fMess desktop chưa có trong bản Android này. Thông báo đẩy nền cũng chưa được triển khai.

## Tạo APK bằng GitHub Actions

1. Giải nén gói này.
2. Tải lên **nội dung bên trong** gói vào thư mục gốc repo `nguyen3nguyen67-tech/fmess`, giữ nguyên cấu trúc `android/` và `.github/workflows/`.
3. Trên GitHub mở repo → **Actions** → **Build fMess Android APK** → **Run workflow**.
4. Khi workflow chạy thành công, mở lần chạy đó, kéo xuống **Artifacts**, tải `fMess-Android-0.1.28-debug` và giải nén để lấy `app-debug.apk`.

Workflow tự cài Android SDK và build APK debug. APK debug dùng để thử nghiệm/cài thủ công; trước khi phát hành rộng rãi cần cấu hình ký APK release bằng keystore riêng.

## Lưu ý

- Cần kết nối Internet để dùng Messenger.
- Facebook/Meta có thể thay đổi website hoặc hạn chế WebView bên thứ ba; khi đó ứng dụng có thể cần cập nhật.
- Đây là ứng dụng không chính thức, không được Meta xác nhận hay bảo trợ.
